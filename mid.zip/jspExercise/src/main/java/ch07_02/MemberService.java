package ch07_02;

import java.sql.SQLException;
import java.util.List;

import ch06_02.MemberBean;

public class MemberService {
	
	MemberDao dao = null;
	
	public MemberService(String dbString) {
		dao = new MemberDao(dbString);
	}	

	public ch07_02.MemberBean select(int id) {
		return dao.select(id);
	}
	
	public List<ch07_02.MemberBean> select() {
		return dao.select();
	}

	public ch07_02.MemberBean insertMember(ch07_02.MemberBean bean) throws SQLException {
		return dao.insertMember(bean);
	}

	public int delete(int id) {
		return dao.delete(id);
	}
}